chunk-MI3OFPKM.js?v=1b70cdae:21607 Download the React DevTools for a better development experience: https://reactjs.org/link/react-devtools
FontLoader.js:37 Font loaded: DigitalDisco
FontLoader.js:37 Font loaded: DigitalDisco-Thin
FontLoader.js:66 All game fonts loaded successfully
App.js:12 All game fonts loaded
GameContainer.js:121 Starting new game with setup: Object
SpaceGame.js:64 [SpaceGame] === INITIALIZING GAME ===
SpaceGame.js:65 [SpaceGame] Canvas: 300 x 150
SpaceGame.js:73 [SpaceGame] Step 1: Creating Game instance with config...
SpaceGame.js:74 [SpaceGame] Initial state: Object
SpriteManager.js:51 [SpriteManager] Initialized
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: ReferenceError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: solidCrust is not defined
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: ReferenceError: solidCrust is not defined
    at CelestialBodyAssetGenerator.createLavaPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:665:7)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:144:37)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:892:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: lava_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:892:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:892:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:303 Total layers created: 3
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:303 Total layers created: 4
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:225
 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:226
 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:227
 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:228
 Total layers created: 1
 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:224
 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:225
 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:226
 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:227
 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:228
 Total layers created: 1
 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:224
 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:225
 Error message: this.generateLowerClouds is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:226
 Error stack: TypeError: this.generateLowerClouds is not a function
    at CelestialBodyAssetGenerator.createGasGiantLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:449:22)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:133:37)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:892:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:227
 Planet type: gas_giant
createCelestialAsset @ CelestialBodyAssetGenerator.js:228
 Total layers created: 1
 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:224
 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:225
 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:226
 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:227
 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:228
 Total layers created: 1
 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:224
 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:225
 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:226
 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:227
 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:228
 Total layers created: 1
 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:224
 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:225
 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:226
 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:227
 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:228
 Total layers created: 1
 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:224
 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:225
 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:226
 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:227
 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:228
 Total layers created: 1
 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:224
 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:225
 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:226
 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:227
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateLowerClouds is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateLowerClouds is not a function
    at CelestialBodyAssetGenerator.createGasGiantLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:449:22)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:133:37)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:892:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: gas_giant
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:303 Total layers created: 4
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:303 Total layers created: 2
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:303 Total layers created: 2
CelestialBodyAssetGenerator.js:303 Total layers created: 2
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:303 Total layers created: 2
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
CelestialBodyAssetGenerator.js:303 Total layers created: 2
CelestialBodyAssetGenerator.js:295 !!! Error creating surface layers !!!
createCelestialAsset @ CelestialBodyAssetGenerator.js:295
CelestialBodyAssetGenerator.js:296 Error type: TypeError
createCelestialAsset @ CelestialBodyAssetGenerator.js:296
CelestialBodyAssetGenerator.js:297 Error message: this.generateSmoothPlains is not a function
createCelestialAsset @ CelestialBodyAssetGenerator.js:297
CelestialBodyAssetGenerator.js:298 Error stack: TypeError: this.generateSmoothPlains is not a function
    at CelestialBodyAssetGenerator.createRockyPlanetLayers (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:353:20)
    at CelestialBodyAssetGenerator.createCelestialAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:128:36)
    at CelestialBodyAssetGenerator.generateAsset (http://localhost:3000/src/engine/CelestialBodyAssetGenerator.js:33:26)
    at Game.preGenerateSystemAssets (http://localhost:3000/src/engine/Game.js:902:62)
    at Game.loadStarSystem (http://localhost:3000/src/engine/Game.js:876:12)
    at new Game (http://localhost:3000/src/engine/Game.js:292:10)
    at http://localhost:3000/src/components/SpaceGame.js:67:14
    at commitHookEffectListMount (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:16961:34)
    at commitPassiveMountOnFiber (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18204:19)
    at commitPassiveMountEffects_complete (http://localhost:3000/node_modules/.vite/deps/chunk-MI3OFPKM.js?v=1b70cdae:18177:17)
createCelestialAsset @ CelestialBodyAssetGenerator.js:298
CelestialBodyAssetGenerator.js:299 Planet type: rocky_planet
createCelestialAsset @ CelestialBodyAssetGenerator.js:299
CelestialBodyAssetGenerator.js:303 Total layers created: 1
Game.js:422 [Performance] Initializing galaxy systems asynchronously...
SpaceGame.js:78 [SpaceGame] Step 2: Game instance created successfully!
SpaceGame.js:88 [SpaceGame] Step 3: New game started with configuration
SpaceGame.js:91 [SpaceGame] Step 4: Setting up intervals...
SpaceGame.js:108 [SpaceGame] === GAME INITIALIZED SUCCESSFULLY ===
Game.js:437 [Performance] Galaxy systems initialized
